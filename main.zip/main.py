import os
import shlex
import shutil
import sqlite3
import subprocess
import sys
from datetime import datetime

from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit,
    QPushButton, QTextEdit, QCheckBox, QGridLayout, QMessageBox,
    QTabWidget, QFileDialog, QComboBox, QListWidget, QListWidgetItem, QSplitter
)

DB_PATH = os.path.join(os.path.dirname(__file__), "nsec_toolkit_expert.db")


# -------------------- DB / Audit --------------------

def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""CREATE TABLE IF NOT EXISTS audit (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT,
        email TEXT,
        action TEXT,
        command TEXT,
        target TEXT,
        mode TEXT,
        container INTEGER,
        timestamp TEXT
    )""")
    cur.execute("""CREATE TABLE IF NOT EXISTS scans (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        audit_id INTEGER,
        tool TEXT,
        target TEXT,
        raw_args TEXT,
        return_code INTEGER,
        output TEXT,
        created_at TEXT,
        FOREIGN KEY(audit_id) REFERENCES audit(id)
    )""")
    conn.commit()
    conn.close()


def record_audit(username, email, action, command, target, mode, container):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    ts = datetime.utcnow().isoformat()
    cur.execute(
        "INSERT INTO audit (username, email, action, command, target, mode, container, timestamp) VALUES (?,?,?,?,?,?,?,?)",
        (username, email, action, command, target, mode, int(bool(container)), ts))
    aid = cur.lastrowid
    conn.commit()
    conn.close()
    return aid


def record_scan(audit_id, tool, target, raw_args, rc, output):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    ts = datetime.utcnow().isoformat()
    cur.execute(
        "INSERT INTO scans (audit_id, tool, target, raw_args, return_code, output, created_at) VALUES (?,?,?,?,?,?,?)",
        (audit_id, tool, target, raw_args, rc, output, ts))
    sid = cur.lastrowid
    conn.commit()
    conn.close()
    return sid


def list_history():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute("""SELECT s.id, a.username, a.email, s.tool, s.target, s.created_at, s.return_code
                   FROM scans s JOIN audit a ON s.audit_id=a.id ORDER BY s.created_at DESC""")
    rows = cur.fetchall()
    conn.close()
    return rows


def get_scan_output(scan_id):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(
        "SELECT s.output, s.raw_args, a.username, a.email, s.return_code, s.created_at FROM scans s JOIN audit a ON s.audit_id=a.id WHERE s.id=?",
        (scan_id,))
    r = cur.fetchone()
    conn.close()
    return r


# -------------------- Worker --------------------

class CommandWorker(QThread):
    progress = Signal(str)
    finished = Signal(int, str, str)  # rc, stdout, stderr

    def __init__(self, args, name):
        super().__init__()
        self.args = args
        self.name = name
        self.proc = None

    def run(self):
        try:
            self.progress.emit(f"اجرای: {' '.join(shlex.quote(a) for a in self.args)}")
            self.proc = subprocess.Popen(self.args, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            stdout, stderr = self.proc.communicate()
            rc = self.proc.returncode
            self.finished.emit(rc, stdout or "", stderr or "")
        except Exception as e:
            self.finished.emit(1, "", str(e))

    def terminate(self):
        try:
            if self.proc and self.proc.poll() is None:
                self.proc.terminate()
        except Exception:
            pass
        super().terminate()


# -------------------- Utilities --------------------

def find_runtime():
    # prefer podman, then docker
    p = shutil.which('podman') or shutil.which('docker')
    return p


def which_or_none(cmd):
    return shutil.which(cmd)


def safe_shlex_split(s):
    try:
        return shlex.split(s)
    except Exception:
        return [s]


# -------------------- GUI --------------------

class MainApp(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Safe-net")
        self.resize(1200, 750)
        self.workers = []
        self.current_audit_id = None
        self._build_ui()
        init_db()
        self.refresh_history()

    def _build_ui(self):
        main = QVBoxLayout()
        # --- user info (required for audit) ---
        user_row = QHBoxLayout()
        user_row.addWidget(QLabel(":نام مهندس"))
        self.user_name = QLineEdit()
        self.user_name.setPlaceholderText("مثلاً: mahdi")
        user_row.addWidget(self.user_name)
        user_row.addWidget(QLabel(":ایمیل"))
        self.user_email = QLineEdit()
        self.user_email.setPlaceholderText("مثلاً: you@gmail.com")
        user_row.addWidget(self.user_email)
        self.container_chk = QCheckBox("Run in container if available (podman/docker)")
        user_row.addWidget(self.container_chk)
        main.addLayout(user_row)

        # --- target input ---
        top = QHBoxLayout()
        top.addWidget(QLabel("Target (IP/CIDR or hostname):"))
        self.target_input = QLineEdit()
        self.target_input.setPlaceholderText("مثال: 192.168.1.0/24 یا example.com")
        top.addWidget(self.target_input)
        load_btn = QPushButton("Load from file")
        load_btn.clicked.connect(self.load_targets_file)
        top.addWidget(load_btn)
        main.addLayout(top)

        # --- tabs ---
        self.tabs = QTabWidget()
        self.tabs.addTab(self._nmap_tab(), "Nmap")
        self.tabs.addTab(self._nettools_tab(), "Network Tools")
        self.tabs.addTab(self._dnswhois_tab(), "DNS & Whois")
        self.tabs.addTab(self._local_tab(), "Local Info")
        self.tabs.addTab(self._advanced_tab(), "Advanced (Raw)")
        main.addWidget(self.tabs)

        # preview & controls
        self.preview = QLineEdit()
        self.preview.setReadOnly(True)
        main.addWidget(QLabel("Command preview:"))
        main.addWidget(self.preview)

        btn_row = QHBoxLayout()
        self.run_btn = QPushButton("Run Selected (Expert)")
        self.run_btn.clicked.connect(self.run_selected)
        self.cancel_btn = QPushButton("Cancel All")
        self.cancel_btn.clicked.connect(self.cancel_all)
        self.refresh_btn = QPushButton("Refresh History")
        self.refresh_btn.clicked.connect(self.refresh_history)
        btn_row.addWidget(self.run_btn)
        btn_row.addWidget(self.cancel_btn)
        btn_row.addWidget(self.refresh_btn)
        main.addLayout(btn_row)

        # results and history split
        splitter = QSplitter(Qt.Horizontal)
        # left: history
        left_w = QWidget()
        left_layout = QVBoxLayout()
        left_w.setLayout(left_layout)
        left_layout.addWidget(QLabel("History (scans)"))
        self.history_list = QListWidget()
        self.history_list.itemClicked.connect(self.on_history_click)
        left_layout.addWidget(self.history_list)
        # right: console / output
        right_w = QWidget()
        right_layout = QVBoxLayout()
        right_w.setLayout(right_layout)
        right_layout.addWidget(QLabel("Console Output"))
        self.console = QTextEdit()
        self.console.setReadOnly(True)
        right_layout.addWidget(self.console)
        splitter.addWidget(left_w)
        splitter.addWidget(right_w)
        main.addWidget(splitter, stretch=1)

        self.setLayout(main)

    # ------------- tabs content -------------
    def _nmap_tab(self):
        w = QWidget()
        layout = QVBoxLayout()
        g = QGridLayout()
        self.cb_top100 = QCheckBox("Top 100 ports")
        self.cb_syn = QCheckBox("TCP SYN (-sS)")
        self.cb_connect = QCheckBox("TCP Connect (-sT)")
        self.cb_udp = QCheckBox("UDP (-sU)")
        self.cb_os = QCheckBox("OS detect (-O)")
        self.cb_service = QCheckBox("Service/version (-sV)")
        self.cb_aggr = QCheckBox("Aggressive (-A)")
        self.cb_ping = QCheckBox("Ping only (-sn)")
        self.port_input = QLineEdit()
        self.scripts_input = QLineEdit()
        self.timing_combo = QComboBox()
        self.timing_combo.addItems(['0', '1', '2', '3', '4', '5'])
        g.addWidget(self.cb_top100, 0, 0)
        g.addWidget(self.cb_syn, 0, 1)
        g.addWidget(self.cb_connect, 1, 0)
        g.addWidget(self.cb_udp, 1, 1)
        g.addWidget(self.cb_os, 2, 0)
        g.addWidget(self.cb_service, 2, 1)
        g.addWidget(self.cb_aggr, 3, 0)
        g.addWidget(self.cb_ping, 3, 1)
        g.addWidget(QLabel("Ports:"), 4, 0)
        g.addWidget(self.port_input, 4, 1)
        g.addWidget(QLabel("Scripts (comma):"), 5, 0)
        g.addWidget(self.scripts_input, 5, 1)
        g.addWidget(QLabel("Timing T:"), 6, 0)
        g.addWidget(self.timing_combo, 6, 1)
        layout.addLayout(g)
        w.setLayout(layout)
        return w

    def _nettools_tab(self):
        w = QWidget()
        layout = QVBoxLayout()
        h = QHBoxLayout()
        self.cb_ping_tool = QCheckBox("Ping")
        self.ping_count = QLineEdit("3")
        self.ping_count.setFixedWidth(60)
        self.cb_traceroute = QCheckBox("Traceroute")
        h.addWidget(self.cb_ping_tool)
        h.addWidget(QLabel("Count:"))
        h.addWidget(self.ping_count)
        h.addWidget(self.cb_traceroute)
        layout.addLayout(h)
        w.setLayout(layout)
        return w

    def _dnswhois_tab(self):
        w = QWidget()
        layout = QHBoxLayout()
        self.cb_whois = QCheckBox("Whois")
        self.cb_dig = QCheckBox("Dig")
        self.dig_type = QComboBox()
        self.dig_type.addItems(['A', 'AAAA', 'MX', 'NS', 'TXT'])
        layout.addWidget(self.cb_whois)
        layout.addWidget(self.cb_dig)
        layout.addWidget(QLabel("Type:"))
        layout.addWidget(self.dig_type)
        w.setLayout(layout)
        return w

    def _local_tab(self):
        w = QWidget()
        layout = QHBoxLayout()
        self.cb_arp = QCheckBox("ARP")
        self.cb_ip = QCheckBox("ip a")
        self.cb_ss = QCheckBox("ss -tunap")
        layout.addWidget(self.cb_arp)
        layout.addWidget(self.cb_ip)
        layout.addWidget(self.cb_ss)
        w.setLayout(layout)
        return w

    def _advanced_tab(self):
        w = QWidget()
        layout = QVBoxLayout()
        layout.addWidget(QLabel("Advanced / Raw Arguments — (Expert mode: unrestricted)"))
        self.raw_tool = QComboBox()
        self.raw_tool.addItems(['nmap', 'ping', 'traceroute', 'whois', 'dig', 'custom'])
        self.raw_args = QLineEdit()
        self.raw_args.setPlaceholderText("مثال برای nmap: -sS -p 22,80 --script vuln")
        layout.addWidget(QLabel("Tool:"))
        layout.addWidget(self.raw_tool)
        layout.addWidget(QLabel("Raw args (will be used as-is):"))
        layout.addWidget(self.raw_args)
        w.setLayout(layout)
        return w

    # ------------- actions -------------
    def load_targets_file(self):
        path, _ = QFileDialog.getOpenFileName(self, "Load targets", ".", "Text files (*.txt);;All files (*)")
        if path:
            try:
                with open(path, 'r', encoding='utf-8') as f:
                    lines = [l.strip() for l in f if l.strip()]
                if lines:
                    self.target_input.setText(lines[0])
                    QMessageBox.information(self, "Loaded", f"{len(lines)} targets loaded (MVP: uses first).")
            except Exception as e:
                QMessageBox.warning(self, "Error", f"خطا: {e}")

    def aggregate_preview(self):
        t = self.target_input.text().strip() or "<target>"
        parts = []
        if any([self.cb_top100.isChecked(), self.cb_syn.isChecked(), self.cb_connect.isChecked(),
                self.cb_udp.isChecked(), self.cb_os.isChecked(), self.cb_service.isChecked(),
                self.cb_aggr.isChecked(), self.cb_ping.isChecked(), self.port_input.text().strip(),
                self.scripts_input.text().strip()]):
            args = ['nmap']
            if self.cb_top100.isChecked(): args += ['--top-ports', '100']
            if self.cb_syn.isChecked(): args += ['-sS']
            if self.cb_connect.isChecked(): args += ['-sT']
            if self.cb_udp.isChecked(): args += ['-sU']
            if self.cb_os.isChecked(): args += ['-O']
            if self.cb_service.isChecked(): args += ['-sV']
            if self.cb_aggr.isChecked(): args += ['-A']
            if self.cb_ping.isChecked(): args += ['-sn']
            if self.port_input.text().strip(): args += ['-p', self.port_input.text().strip()]
            if self.scripts_input.text().strip(): args += ['--script', self.scripts_input.text().strip()]
            args += ['-oX', '-']
            args.append(t)
            parts.append(" ".join(shlex.quote(a) for a in args))
        if self.cb_ping_tool.isChecked():
            parts.append(f"ping -c {self.ping_count.text().strip()} {t}")
        if self.cb_traceroute.isChecked():
            parts.append(f"traceroute {t}")
        if self.cb_whois.isChecked():
            parts.append(f"whois {t}")
        if self.cb_dig.isChecked():
            parts.append(f"dig {t} {self.dig_type.currentText()}")
        local_parts = []
        if self.cb_arp.isChecked(): local_parts.append("arp -n")
        if self.cb_ip.isChecked(): local_parts.append("ip a")
        if self.cb_ss.isChecked(): local_parts.append("ss -tunap")
        if local_parts:
            parts.append(" | ".join(local_parts))
        # raw
        if self.raw_args.text().strip():
            rt = self.raw_tool.currentText()
            parts.append(f"RAW({rt}) {self.raw_args.text().strip()}")
        self.preview.setText(" || ".join(parts))

    def run_selected(self):
        # check user info present
        uname = self.user_name.text().strip()
        uemail = self.user_email.text().strip()
        if not uname or not uemail:
            QMessageBox.warning(self, "اطلاعات کاربر لازم است", "برای ثبت لاگ و مسئولیت، نام و ایمیل خود را وارد کنید.")
            return

        target = self.target_input.text().strip()
        if not target:
            QMessageBox.warning(self, "Target required", "ابتدا target را وارد کنید.")
            return

        # create audit entry for this run (mode=EXPERT by design)
        container_runtime = find_runtime() if self.container_chk.isChecked() else None
        full_command_summary = self.preview.text() or "manual"
        aid = record_audit(uname, uemail, "RUN_BATCH", full_command_summary, target, "EXPERT", bool(container_runtime))
        self.current_audit_id = aid

        # run selected tools (each in own thread)
        # Nmap if configured
        if any([self.cb_top100.isChecked(), self.cb_syn.isChecked(), self.cb_connect.isChecked(),
                self.cb_udp.isChecked(), self.cb_os.isChecked(), self.cb_service.isChecked(),
                self.cb_aggr.isChecked(), self.cb_ping.isChecked(), self.port_input.text().strip(),
                self.scripts_input.text().strip()]):
            args = ['nmap']
            if self.cb_top100.isChecked(): args += ['--top-ports', '100']
            if self.cb_syn.isChecked(): args += ['-sS']
            if self.cb_connect.isChecked(): args += ['-sT']
            if self.cb_udp.isChecked(): args += ['-sU']
            if self.cb_os.isChecked(): args += ['-O']
            if self.cb_service.isChecked(): args += ['-sV']
            if self.cb_aggr.isChecked(): args += ['-A']
            if self.cb_ping.isChecked(): args += ['-sn']
            if self.port_input.text().strip(): args += ['-p', self.port_input.text().strip()]
            if self.scripts_input.text().strip(): args += ['--script', self.scripts_input.text().strip()]
            args += ['-oX', '-']
            args.append(target)
            self._run_tool_thread("nmap", args, aid, target, " ".join(args), container_runtime)

        # Ping
        if self.cb_ping_tool.isChecked():
            ping_cmd = which_or_none('ping') or 'ping'
            cnt = 3
            try:
                cnt = int(self.ping_count.text().strip())
            except:
                cnt = 3
            args = [ping_cmd, '-c', str(cnt), target]
            self._run_tool_thread("ping", args, aid, target, " ".join(args), container_runtime)

        # Traceroute
        if self.cb_traceroute.isChecked():
            tr = which_or_none('traceroute') or 'traceroute'
            args = [tr, target]
            self._run_tool_thread("traceroute", args, aid, target, " ".join(args), container_runtime)

        # Whois
        if self.cb_whois.isChecked():
            w = which_or_none('whois') or 'whois'
            args = [w, target]
            self._run_tool_thread("whois", args, aid, target, " ".join(args), container_runtime)

        # dig
        if self.cb_dig.isChecked():
            d = which_or_none('dig') or 'dig'
            q = self.dig_type.currentText()
            args = [d, target, q]
            self._run_tool_thread("dig", args, aid, target, " ".join(args), container_runtime)

        # local tools
        if self.cb_arp.isChecked():
            arp = which_or_none('arp') or 'arp'
            args = [arp, '-n'] if arp.endswith('arp') else [arp]
            self._run_tool_thread("arp", args, aid, target, " ".join(args), container_runtime)
        if self.cb_ip.isChecked():
            ip = which_or_none('ip') or 'ip'
            args = [ip, 'a']
            self._run_tool_thread("ip", args, aid, target, " ".join(args), container_runtime)
        if self.cb_ss.isChecked():
            ss = which_or_none('ss') or 'ss'
            args = [ss, '-tunap']
            self._run_tool_thread("ss", args, aid, target, " ".join(args), container_runtime)

        # raw / advanced: UNRESTRICTED — expert mode
        raw_text = self.raw_args.text().strip()
        if raw_text:
            rt = self.raw_tool.currentText()
            if rt == 'custom':
                toks = safe_shlex_split(raw_text)
                args = toks
            else:
                toks = safe_shlex_split(raw_text)
                cmd_path = which_or_none(rt) or rt
                args = [cmd_path] + toks
                if rt == 'nmap' and target not in args:
                    args = [cmd_path] + toks + [target]
            self._run_tool_thread(f"raw:{rt}", args, aid, target, " ".join(args), container_runtime)

        self.aggregate_preview()
        self.refresh_history()

    def _run_tool_thread(self, tool_name, args, audit_id, target, raw_cmd_str, container_runtime):
        if container_runtime:
            runtime = container_runtime
            image = "nmaptools:latest"
            run_in_container = False
            if shutil.which(runtime):
                img_check = subprocess.run([runtime, "images", "-q", image], capture_output=True, text=True)
                if img_check.returncode == 0 and img_check.stdout.strip():
                    run_in_container = True
            if run_in_container:
                container_cmd = [runtime, "run", "--rm", "--network", "host", image] + args
                final_args = container_cmd
            else:
                final_args = args
        else:
            final_args = args

        # spawn thread
        w = CommandWorker(final_args, tool_name)
        w.progress.connect(self.on_progress)

        def finish_cb(rc, stdout, stderr):
            out = stdout or ""
            if stderr:
                out += ("\n[stderr]\n" + stderr)
            record_scan(audit_id, tool_name, target, raw_cmd_str, rc, out)
            self.on_finished(tool_name, rc, out)

        w.finished.connect(lambda rc, so, se: finish_cb(rc, so, se))
        w.start()
        self.workers.append(w)
        item = QListWidgetItem(f"{datetime.utcnow().isoformat()}  {tool_name}  target={target}")
        self.history_list.insertItem(0, item)

    def on_progress(self, s):
        ts = datetime.now().strftime("%H:%M:%S")
        self.console.append(f"[{ts}] {s}")

    def on_finished(self, tool_name, rc, out):
        ts = datetime.now().strftime("%H:%M:%S")
        header = f"\n=== [{ts}] {tool_name} finished (rc={rc}) ===\n"
        self.console.append(header + out + "\n")

    def cancel_all(self):
        for w in self.workers:
            try:
                w.terminate()
            except:
                pass
        self.workers = []
        self.console.append("[User cancelled all jobs]\n")

    # ------------- history -------------
    def refresh_history(self):
        self.history_list.clear()
        rows = list_history()
        for r in rows:
            sid, uname, email, tool, target, created_at, rc = r
            it = QListWidgetItem(f"{sid} | {created_at} | {tool} | {target} | rc={rc} | {uname}")
            it.setData(Qt.UserRole, sid)
            self.history_list.addItem(it)

    def on_history_click(self, item):
        sid = item.data(Qt.UserRole)
        data = get_scan_output(sid)
        if not data:
            QMessageBox.information(self, "No data", "Record not found")
            return
        output, raw_args, uname, email, rc, created_at = data
        dlg = QMessageBox(self)
        dlg.setWindowTitle(f"Scan {sid} — details")
        dlg.setText(
            f"User: {uname} <{email}>\nTime: {created_at}\nReturn code: {rc}\n\nRaw args: {raw_args}\n\nOutput (truncated):\n{output[:4000]}")
        dlg.exec()

    def aggregate_preview(self):
        t = self.target_input.text().strip() or "<target>"
        parts = []
        # similar to run_selected make a summary
        if any([self.cb_top100.isChecked(), self.cb_syn.isChecked(), self.cb_connect.isChecked(),
                self.cb_udp.isChecked(), self.cb_os.isChecked(), self.cb_service.isChecked(),
                self.cb_aggr.isChecked(), self.cb_ping.isChecked(), self.port_input.text().strip(),
                self.scripts_input.text().strip()]):
            s = "nmap "
            if self.cb_top100.isChecked(): s += "--top-ports 100 "
            if self.cb_syn.isChecked(): s += "-sS "
            if self.cb_connect.isChecked(): s += "-sT "
            if self.cb_udp.isChecked(): s += "-sU "
            if self.cb_os.isChecked(): s += "-O "
            if self.cb_service.isChecked(): s += "-sV "
            if self.cb_aggr.isChecked(): s += "-A "
            if self.cb_ping.isChecked(): s += "-sn "
            if self.port_input.text().strip(): s += f"-p {self.port_input.text().strip()} "
            if self.scripts_input.text().strip(): s += f"--script {self.scripts_input.text().strip()} "
            s += f"-oX - {t}"
            parts.append(s)
        if self.cb_ping_tool.isChecked(): parts.append(f"ping -c {self.ping_count.text().strip()} {t}")
        if self.cb_traceroute.isChecked(): parts.append(f"traceroute {t}")
        if self.cb_whois.isChecked(): parts.append(f"whois {t}")
        if self.cb_dig.isChecked(): parts.append(f"dig {t} {self.dig_type.currentText()}")
        local = []
        if self.cb_arp.isChecked(): local.append("arp -n")
        if self.cb_ip.isChecked(): local.append("ip a")
        if self.cb_ss.isChecked(): local.append("ss -tunap")
        if local: parts.append(" | ".join(local))
        if self.raw_args.text().strip():
            parts.append(f"RAW({self.raw_tool.currentText()}): {self.raw_args.text().strip()}")
        self.preview.setText(" || ".join(parts))

    def closeEvent(self, event):
        if self.workers:
            if QMessageBox.question(self, "Exit", "برنامه در حال اجرا است مطمئنی می‌خوای خارج شی؟",
                                    QMessageBox.Yes | QMessageBox.No) != QMessageBox.Yes:
                event.ignore()
                return
        event.accept()


# -------------------- Main --------------------
def main():
    app = QApplication(sys.argv)
    win = MainApp()

    # wire inputs to preview
    widgets = [
        win.target_input, win.cb_top100, win.cb_syn, win.cb_connect, win.cb_udp, win.cb_os, win.cb_service,
        win.cb_aggr, win.cb_ping, win.port_input, win.scripts_input, win.timing_combo, win.cb_ping_tool,
        win.ping_count, win.cb_traceroute, win.cb_whois, win.cb_dig, win.dig_type,
        win.cb_arp, win.cb_ip, win.cb_ss, win.raw_tool, win.raw_args
    ]
    for w in widgets:
        try:
            w.textChanged.connect(win.aggregate_preview)
        except Exception:
            try:
                w.stateChanged.connect(win.aggregate_preview)
            except Exception:
                try:
                    w.currentIndexChanged.connect(win.aggregate_preview)
                except Exception:
                    pass
    win.aggregate_preview()
    win.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
